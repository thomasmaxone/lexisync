import { base44 } from './base44Client';


export const Entity = base44.entities.Entity;



// auth sdk:
export const User = base44.auth;